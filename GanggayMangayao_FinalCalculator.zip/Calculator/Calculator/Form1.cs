﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculator
{
    public partial class Form1 : Form
    {
        String num1 = "0", num2 = "0";
        
        public static bool minusButtonClicked = false;
        public static bool plusButtonClicked = false;
        public static bool divideButtonClicked = false;
        public static bool multiplyButtonClicked = false;

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            //if (DecVar.plusButtonClicked == false/* || DecVar.minusButtonClicked == false || DecVar.multiplyButtonClicked == false || DecVar.divideButtonClicked == false*/)
            //{
               
            //    ans.Text = ans.Text + 1;
            //    num1 = num1 + 1;
            //    DecVar.total1 = Convert.ToDouble(num1) ;
                
            //}
             if (DecVar.plusButtonClicked == true /*|| DecVar.minusButtonClicked == true || DecVar.multiplyButtonClicked == true || DecVar.divideButtonClicked == true*/)
            {
                ans.Text = ans.Text + 1;
                num2 = num2 + 1;
                
                DecVar.total2 = Convert.ToDouble(num2);
            }

            else if (DecVar.minusButtonClicked == true)
            {
                ans.Text = ans.Text + 1;
                num2 = num2 + 1;
                DecVar.total2 = Convert.ToDouble(num2);
            }

            else if (DecVar.multiplyButtonClicked == true)
            {
                ans.Text = ans.Text + 1;
                num2 = num2 + 1;
                DecVar.total2 = Convert.ToDouble(num2);
            }
            else if (DecVar.divideButtonClicked == true)
            {
                ans.Text = ans.Text + 1;
                num2 = num2 + 1;
                DecVar.total2 = Convert.ToDouble(num2);
            }

            else
            {
                ans.Text = ans.Text + 1;
                num1 = num1 + 1;
                DecVar.total1 = Convert.ToDouble(num1) ;

            }


            /*

            if (tb1.Enabled == true)

            {
                tb1.Text = tb1.Text + "1";

                DecVar.total1 = 1;
            //   ans.Text = ans.Text + 1;

            }
            else
            {
                tb2.Text = tb2.Text + "1";
                DecVar.total2 = 1;
            }
            */
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (DecVar.plusButtonClicked == true /*|| DecVar.minusButtonClicked == true || DecVar.multiplyButtonClicked == true || DecVar.divideButtonClicked == true*/)
            {
                ans.Text = ans.Text + 2;
                num2 = num2 + 2;

                DecVar.total2 = Convert.ToDouble(num2);
            }

            else if (DecVar.minusButtonClicked == true)
            {
                ans.Text = ans.Text +2;
                num2 = num2 + 2;
                DecVar.total2 = Convert.ToDouble(num2);
            }

            else if (DecVar.multiplyButtonClicked == true)
            {
                ans.Text = ans.Text + 2;
                num2 = num2 +2;
                DecVar.total2 = Convert.ToDouble(num2);
            }
            else if (DecVar.divideButtonClicked == true)
            {
                ans.Text = ans.Text + 2;
                num2 = num2 + 2;
                DecVar.total2 = Convert.ToDouble(num2);
            }

            else
            {
                ans.Text = ans.Text + 2;
                num1 = num1 + 2;
                DecVar.total1 = Convert.ToDouble(num1);

            }




            /*


            if (tb1.Enabled == true)

            {
                tb1.Text = tb1.Text + "2";
                DecVar.total1 = 2;

            }
            else
            {
                tb2.Text = tb2.Text + "2";
                DecVar.total1 = 2;
            }*/
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (DecVar.plusButtonClicked == true /*|| DecVar.minusButtonClicked == true || DecVar.multiplyButtonClicked == true || DecVar.divideButtonClicked == true*/)
            {
                ans.Text = ans.Text + 3;
                num2 = num2 + 3;

                DecVar.total2 = Convert.ToDouble(num2);
            }

            else if (DecVar.minusButtonClicked == true)
            {
                ans.Text = ans.Text +3;
                num2 = num2 + 3;
                DecVar.total2 = Convert.ToDouble(num2);
            }

            else if (DecVar.multiplyButtonClicked == true)
            {
                ans.Text = ans.Text + 3;
                num2 = num2 + 3;
                DecVar.total2 = Convert.ToDouble(num2);
            }
            else if (DecVar.divideButtonClicked == true)
            {
                ans.Text = ans.Text + 3;
                num2 = num2 + 3;
                DecVar.total2 = Convert.ToDouble(num2);
            }

            else
            {
                ans.Text = ans.Text + 3;
                num1 = num1 + 3;
                DecVar.total1 = Convert.ToDouble(num1);

            }


            /*
            if (tb1.Enabled == true)

            {
                tb1.Text = tb1.Text + "3";
                DecVar.total1 = 3;

            }
            else
            {
                tb2.Text = tb2.Text + "3";
                DecVar.total1 = 3;
            }*/
        }

        private void button4_Click(object sender, EventArgs e)
        {
            ope.Text = "+";
            tb1.Enabled = false;

            
            DecVar.plusButtonClicked = true;
            ans.Text = ans.Text + "+";

        }

        private void button17_Click(object sender, EventArgs e)
        {
            if (DecVar.plusButtonClicked == true)
            {
                ans.Text = (Convert.ToDouble(DecVar.total1) + Convert.ToDouble(DecVar.total2)).ToString();
               
            }
            else if (DecVar.minusButtonClicked == true)
            {
                ans.Text = (Convert.ToDouble(DecVar.total1) - Convert.ToDouble(DecVar.total2)).ToString();
            }
            else if (DecVar.multiplyButtonClicked == true)
            {
                ans.Text = (Convert.ToDouble(DecVar.total1) * Convert.ToDouble(DecVar.total2)).ToString();
            }

            else if (DecVar.divideButtonClicked == true)
            {
                ans.Text = (Convert.ToDouble(DecVar.total1) / Convert.ToDouble(DecVar.total2)).ToString();
            }


            /*if (ope.Text == "+")
            {
                ans.Text = (Convert.ToDouble(tb1.Text) + Convert.ToDouble(tb2.Text)).ToString();
            }
            else if (ope.Text == "-")
            {
                ans.Text = (Convert.ToDouble(tb1.Text) - Convert.ToDouble(tb2.Text)).ToString();
            }
            else if (ope.Text == "/")
            {
                ans.Text = (Convert.ToDouble(tb1.Text) / Convert.ToDouble(tb2.Text)).ToString();
            }
            else if (ope.Text == "*")
            {
                ans.Text = (Convert.ToDouble(tb1.Text) * Convert.ToDouble(tb2.Text)).ToString();
            }*/
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (DecVar.plusButtonClicked == true /*|| DecVar.minusButtonClicked == true || DecVar.multiplyButtonClicked == true || DecVar.divideButtonClicked == true*/)
            {
                ans.Text = ans.Text + 4;
                num2 = num2 +4;

                DecVar.total2 = Convert.ToDouble(num2);
            }

            else if (DecVar.minusButtonClicked == true)
            {
                ans.Text = ans.Text + 4;
                num2 = num2 + 4;
                DecVar.total2 = Convert.ToDouble(num2);
            }

            else if (DecVar.multiplyButtonClicked == true)
            {
                ans.Text = ans.Text + 4;
                num2 = num2 + 4;
                DecVar.total2 = Convert.ToDouble(num2);
            }
            else if (DecVar.divideButtonClicked == true)
            {
                ans.Text = ans.Text + 4;
                num2 = num2 + 4;
                DecVar.total2 = Convert.ToDouble(num2);
            }

            else
            {
                ans.Text = ans.Text + 4;
                num1 = num1 + 4;
                DecVar.total1 = Convert.ToDouble(num1);

            }


            //if (tb1.Enabled == true)

            //{
            //    tb1.Text = tb1.Text + "4";
            //    DecVar.total1 = 4;

            //}
            //else
            //{
            //    tb2.Text = tb2.Text + "4";
            //    DecVar.total1 = 4;
            //}
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (DecVar.plusButtonClicked == true /*|| DecVar.minusButtonClicked == true || DecVar.multiplyButtonClicked == true || DecVar.divideButtonClicked == true*/)
            {
                ans.Text = ans.Text + 5;
                num2 = num2 +5;

                DecVar.total2 = Convert.ToDouble(num2);
            }

            else if (DecVar.minusButtonClicked == true)
            {
                ans.Text = ans.Text + 5;
                num2 = num2 + 5;
                DecVar.total2 = Convert.ToDouble(num2);
            }

            else if (DecVar.multiplyButtonClicked == true)
            {
                ans.Text = ans.Text + 5;
                num2 = num2 + 5;
                DecVar.total2 = Convert.ToDouble(num2);
            }
            else if (DecVar.divideButtonClicked == true)
            {
                ans.Text = ans.Text + 5;
                num2 = num2 + 5;
                DecVar.total2 = Convert.ToDouble(num2);
            }

            else
            {
                ans.Text = ans.Text + 5;
                num1 = num1 + 5;
                DecVar.total1 = Convert.ToDouble(num1);

            }

            //if (tb1.Enabled == true)

            //{
            //    tb1.Text = tb1.Text + "5";
            //    DecVar.total1 = 5;

            //}
            //else
            //{
            //    tb2.Text = tb2.Text + "5";
            //    DecVar.total1 = 5;
            //}
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (DecVar.plusButtonClicked == true /*|| DecVar.minusButtonClicked == true || DecVar.multiplyButtonClicked == true || DecVar.divideButtonClicked == true*/)
            {
                ans.Text = ans.Text + 6;
                num2 = num2 + 6;

                DecVar.total2 = Convert.ToDouble(num2);
            }

            else if (DecVar.minusButtonClicked == true)
            {
                ans.Text = ans.Text + 6;
                num2 = num2 + 6;
                DecVar.total2 = Convert.ToDouble(num2);
            }

            else if (DecVar.multiplyButtonClicked == true)
            {
                ans.Text = ans.Text + 6;
                num2 = num2 + 6;
                DecVar.total2 = Convert.ToDouble(num2);
            }
            else if (DecVar.divideButtonClicked == true)
            {
                ans.Text = ans.Text + 6;
                num2 = num2 + 6;
                DecVar.total2 = Convert.ToDouble(num2);
            }

            else
            {
                ans.Text = ans.Text + 6;
                num1 = num1 + 6;
                DecVar.total1 = Convert.ToDouble(num1);

            }


            //if (tb1.Enabled == true)

            //{
            //    tb1.Text = tb1.Text + "6";
            //    DecVar.total1 = 6;

            //}
            //else
            //{
            //    tb2.Text = tb2.Text + "6";
            //    DecVar.total1 = 6;
            //}
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (DecVar.plusButtonClicked == true /*|| DecVar.minusButtonClicked == true || DecVar.multiplyButtonClicked == true || DecVar.divideButtonClicked == true*/)
            {
                ans.Text = ans.Text + 7;
                num2 = num2 + 7;

                DecVar.total2 = Convert.ToDouble(num2);
            }

            else if (DecVar.minusButtonClicked == true)
            {
                ans.Text = ans.Text + 7;
                num2 = num2 + 7;
                DecVar.total2 = Convert.ToDouble(num2);
            }

            else if (DecVar.multiplyButtonClicked == true)
            {
                ans.Text = ans.Text + 7;
                num2 = num2 + 7;
                DecVar.total2 = Convert.ToDouble(num2);
            }
            else if (DecVar.divideButtonClicked == true)
            {
                ans.Text = ans.Text + 7;
                num2 = num2 + 7;
                DecVar.total2 = Convert.ToDouble(num2);
            }

            else
            {
                ans.Text = ans.Text + 7;
                num1 = num1 + 7;
                DecVar.total1 = Convert.ToDouble(num1);

            }

            //if (tb1.Enabled == true)

            //{
            //    tb1.Text = tb1.Text + "7";
            //    DecVar.total1 = 7;

            //}
            //else
            //{
            //    tb2.Text = tb2.Text + "7";
            //    DecVar.total1 = 7;
            //}
        }

        private void button10_Click(object sender, EventArgs e)
        {
            if (DecVar.plusButtonClicked == true /*|| DecVar.minusButtonClicked == true || DecVar.multiplyButtonClicked == true || DecVar.divideButtonClicked == true*/)
            {
                ans.Text = ans.Text + 8;
                num2 = num2 + 8;

                DecVar.total2 = Convert.ToDouble(num2);
            }

            else if (DecVar.minusButtonClicked == true)
            {
                ans.Text = ans.Text + 8;
                num2 = num2 + 8;
                DecVar.total2 = Convert.ToDouble(num2);
            }

            else if (DecVar.multiplyButtonClicked == true)
            {
                ans.Text = ans.Text + 8;
                num2 = num2 + 8;
                DecVar.total2 = Convert.ToDouble(num2);
            }
            else if (DecVar.divideButtonClicked == true)
            {
                ans.Text = ans.Text + 8;
                num2 = num2 + 8;
                DecVar.total2 = Convert.ToDouble(num2);
            }

            else
            {
                ans.Text = ans.Text + 8;
                num1 = num1 +8;
                DecVar.total1 = Convert.ToDouble(num1);

            }


            //if (tb1.Enabled == true)

            //{
            //    tb1.Text = tb1.Text + "8";
            //    DecVar.total1 = 8;

            //}
            //else
            //{
            //    tb2.Text = tb2.Text + "8";
            //    DecVar.total1 = 8;
            //}
        }

        private void button11_Click(object sender, EventArgs e)
        {
            if (DecVar.plusButtonClicked == true /*|| DecVar.minusButtonClicked == true || DecVar.multiplyButtonClicked == true || DecVar.divideButtonClicked == true*/)
            {
                ans.Text = ans.Text + 9;
                num2 = num2 + 9;

                DecVar.total2 = Convert.ToDouble(num2);
            }

            else if (DecVar.minusButtonClicked == true)
            {
                ans.Text = ans.Text + 9;
                num2 = num2 + 9;
                DecVar.total2 = Convert.ToDouble(num2);
            }

            else if (DecVar.multiplyButtonClicked == true)
            {
                ans.Text = ans.Text + 9;
                num2 = num2 + 9;
                DecVar.total2 = Convert.ToDouble(num2);
            }
            else if (DecVar.divideButtonClicked == true)
            {
                ans.Text = ans.Text + 9;
                num2 = num2 + 9;
                DecVar.total2 = Convert.ToDouble(num2);
            }

            else
            {
                ans.Text = ans.Text + 9;
                num1 = num1 + 9;
                DecVar.total1 = Convert.ToDouble(num1);

            }

            //if (tb1.Enabled == true)

            //{
            //    tb1.Text = tb1.Text + "9";
            //    DecVar.total1 = 9;

            //}
            //else
            //{
            //    tb2.Text = tb2.Text + "9";
            //    DecVar.total1 = 9;
            //}
        }

        private void button13_Click(object sender, EventArgs e)
        {
            if (DecVar.plusButtonClicked == true /*|| DecVar.minusButtonClicked == true || DecVar.multiplyButtonClicked == true || DecVar.divideButtonClicked == true*/)
            {
                ans.Text = ans.Text + 0;
                num2 = num2 +0;

                DecVar.total2 = Convert.ToDouble(num2);
            }

            else if (DecVar.minusButtonClicked == true)
            {
                ans.Text = ans.Text + 0;
                num2 = num2 +0;
                DecVar.total2 = Convert.ToDouble(num2);
            }

            else if (DecVar.multiplyButtonClicked == true)
            {
                ans.Text = ans.Text + 0;
                num2 = num2 + 0;
                DecVar.total2 = Convert.ToDouble(num2);
            }
            else if (DecVar.divideButtonClicked == true)
            {
                ans.Text = ans.Text + 0;
                num2 = num2 +0;
                DecVar.total2 = Convert.ToDouble(num2);
            }

            else
            {
                ans.Text = ans.Text + 0;
                num1 = num1 + 0;
                DecVar.total1 = Convert.ToDouble(num1);

            }


            //if (tb1.Enabled == true)

            //{
            //    tb1.Text = tb1.Text + "0";
            //    DecVar.total1 = 0;

            //}
            //else
            //{
            //    tb2.Text = tb2.Text + "0";
            //    DecVar.total1 = 0;
            //}
        }

        private void button15_Click(object sender, EventArgs e)
        {
            if (DecVar.plusButtonClicked == false /*|| DecVar.minusButtonClicked == false || DecVar.multiplyButtonClicked == false || DecVar.divideButtonClicked == false*/)
            {

                ans.Text = ans.Text + ".";
                num1 = num1 +'.';
                DecVar.total1 = Convert.ToDouble(num1);

            }
            else if (DecVar.plusButtonClicked == true /*|| DecVar.minusButtonClicked == true || DecVar.multiplyButtonClicked == true || DecVar.divideButtonClicked == true*/)
            {
                ans.Text = ans.Text + ".";
                num2 = num2 + '.';
                DecVar.total2 = Convert.ToDouble(num2);
            }

            //if (tb1.Enabled == true)

            //{
            //    tb1.Text = tb1.Text + ".";


            //}
            //else
            //{
            //    tb2.Text = tb2.Text + ".";
            //}
        }

        private void button14_Click(object sender, EventArgs e)
        {
        minusButtonClicked = false;
        plusButtonClicked = false;
        divideButtonClicked = false;
        multiplyButtonClicked = false;

            num1 = "0";
            num2 = "0";

            textBox1.Text = num1;
           
            textBox2.Text = num2;

            ans.Text = "";

        }

        private void button8_Click(object sender, EventArgs e)
        {
            ope.Text = "-";
            tb1.Enabled = false;

            DecVar.minusButtonClicked = true;
            ans.Text = ans.Text + "-";

        }

        private void button12_Click(object sender, EventArgs e)
        {
            ope.Text = "*";
            tb1.Enabled = false;

            DecVar.multiplyButtonClicked = true;
            ans.Text = ans.Text + "*";
        }

        private void button16_Click(object sender, EventArgs e)
        {
            ope.Text = "/";
            tb1.Enabled = false;

            DecVar.divideButtonClicked = true;
            ans.Text = ans.Text + "/";
        }

        private void button18_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
           
        }

        private void ans_TextChanged(object sender, EventArgs e)
        {
            
        }
    }
}
