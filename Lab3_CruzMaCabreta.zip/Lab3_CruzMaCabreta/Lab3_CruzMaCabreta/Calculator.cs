﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Lab3_CruzMaCabreta
{
    public partial class Calculator : Form
    {
        public Calculator()
        {
            InitializeComponent();
        }


        private void Form1_Load(object sender, EventArgs e)
        {

        }



        private void btnPlus_Click(object sender, EventArgs e)
        {
            DeclareVar.total1 = DeclareVar.total1 + double.Parse(txtDisplay.Text);
            txtDisplay.Clear();

            DeclareVar.minusButtonClicked = false;
            DeclareVar.plusButtonClicked = true;
            DeclareVar.divideButtonClicked = false;
            DeclareVar.multiplyButtonClicked = false;
        }
     

        private void btnMinus_Click(object sender, EventArgs e)
        {
            DeclareVar.total1 = DeclareVar.total1 + double.Parse(txtDisplay.Text);
            txtDisplay.Clear();

            DeclareVar.minusButtonClicked = true;
            DeclareVar.plusButtonClicked = false;
            DeclareVar.divideButtonClicked = false;
            DeclareVar.multiplyButtonClicked = false;


        }

        private void btnMultiply_Click(object sender, EventArgs e)
        {
            DeclareVar.total1 = DeclareVar.total1 +  double.Parse(txtDisplay.Text);
            txtDisplay.Clear();

            DeclareVar.minusButtonClicked = false;
            DeclareVar.plusButtonClicked = false;
            DeclareVar.divideButtonClicked = false;
            DeclareVar.multiplyButtonClicked = true;
        }

        private void btnDivide_Click(object sender, EventArgs e)
        {
            DeclareVar.total1 = DeclareVar.total1 + double.Parse(txtDisplay.Text);
            txtDisplay.Clear();

            DeclareVar.minusButtonClicked = false;
            DeclareVar.plusButtonClicked = false;
            DeclareVar.divideButtonClicked = true;
            DeclareVar.multiplyButtonClicked = false;
        }

        private void txtDisplay_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + button1.Text;
        }

        private void button2_Click(object sender, EventArgs e)
        {

            txtDisplay.Text = txtDisplay.Text + button2.Text;



        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (txtDisplay.Text == "0" && txtDisplay.Text != null)
            {
                txtDisplay.Text = "3";

            }

            else
            {

                txtDisplay.Text = txtDisplay.Text + "3";


            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (txtDisplay.Text == "0" && txtDisplay.Text != null)
            {
                txtDisplay.Text = "4";

            }

            else
            {

                txtDisplay.Text = txtDisplay.Text + "4";
            }


        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (txtDisplay.Text == "0" && txtDisplay.Text != null)
            {
                txtDisplay.Text = "5";

            }

            else
            {

                txtDisplay.Text = txtDisplay.Text + "5";
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (txtDisplay.Text == "0" && txtDisplay.Text != null)
            {
                txtDisplay.Text = "6";

            }

            else
            {

                txtDisplay.Text = txtDisplay.Text + "6";
            }

        }
        private void button9_Click(object sender, EventArgs e)
        {
            if (txtDisplay.Text == "0" && txtDisplay.Text != null)
            {
                txtDisplay.Text = "7";

            }

            else
            {

                txtDisplay.Text = txtDisplay.Text + "7";
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            if (txtDisplay.Text == "0" && txtDisplay.Text != null)
            {
                txtDisplay.Text = "8";

            }

            else
            {

                txtDisplay.Text = txtDisplay.Text + "8";
            }
        }

        private void button11_Click(object sender, EventArgs e)
        {
            if (txtDisplay.Text == "0" && txtDisplay.Text != null)
            {
                txtDisplay.Text = "9";

            }

            else
            {

                txtDisplay.Text = txtDisplay.Text + "9";
            }

        }






        private void btnEquals_Click(object sender, EventArgs e)
        {
            if (DeclareVar.plusButtonClicked == true) {
			DeclareVar.total2 = DeclareVar.total1 + double.Parse(txtDisplay.Text);
		}
            else if (DeclareVar.minusButtonClicked == true)
            {
			DeclareVar.total2 = DeclareVar.total1 - double.Parse(txtDisplay.Text);
		}
            else if (DeclareVar.multiplyButtonClicked == true)
            {
			DeclareVar.total2 = DeclareVar.total1 * double.Parse(txtDisplay.Text);
		}
            else if (DeclareVar.divideButtonClicked == true)
            {
			DeclareVar.total2 = DeclareVar.total1 / double.Parse(txtDisplay.Text);
		}

		txtDisplay.Text = DeclareVar.total2.ToString();
        DeclareVar.total1 = 0;
        }

        
        private void btnClear_Click_1(object sender, EventArgs e)
        {
           

            txtDisplay.Clear();
        }

        private void button18_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button14_Click(object sender, EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + button14.Text;
        }

    


            }

        }
        
            

        

        
    
        
    



    






    

