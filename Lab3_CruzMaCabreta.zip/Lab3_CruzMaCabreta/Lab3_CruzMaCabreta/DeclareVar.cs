﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Lab3_CruzMaCabreta
{
    class DeclareVar
    {

        public static double total1 = 0;
        public static double total2 = 0;
        public static bool minusButtonClicked = false;
        public static bool plusButtonClicked = false;
        public static bool divideButtonClicked = false;
        public static bool multiplyButtonClicked = false;

    }
}
