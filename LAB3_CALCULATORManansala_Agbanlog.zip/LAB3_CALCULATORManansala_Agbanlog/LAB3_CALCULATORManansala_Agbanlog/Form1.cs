﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LAB3_CALCULATORManansala_Agbanlog
{
    public partial class Form1 : Form
    {
        Double result = 0;
        String operation = "";
        bool isOp = false;


        public Form1()
        {
            InitializeComponent();
        }


        private void btn_Click(object sender, EventArgs e)
        {
            if (isOp)
                txtbox_result.Clear();
            Button button = (Button)sender;
            txtbox_result.Text = txtbox_result.Text + button.Text;
            isOp = false;
        }

        private void btn_operator(object sender, EventArgs e)
        {
            Button button = (Button)sender;

            operation = button.Text;
            result = Double.Parse(txtbox_result.Text);
            isOp = true;
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtbox_result.Text = "";
            result = 0;

        }

        private void btnEqual_Click(object sender, EventArgs e)
        {
            switch(operation){
            
                case "+":
                    txtbox_result.Text=(result+ Double.Parse(txtbox_result.Text)).ToString();
                    break;
                case "-":
                    txtbox_result.Text = (result - Double.Parse(txtbox_result.Text)).ToString();
                    break;
                case "*":
                    txtbox_result.Text = (result * Double.Parse(txtbox_result.Text)).ToString();
                    break;
                case "/":
                    txtbox_result.Text = (result / Double.Parse(txtbox_result.Text)).ToString();
                    break;

                default:
                    break;
                    

        }
    }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
