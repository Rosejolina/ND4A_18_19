﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LAB3_MORALES_CRUZMI
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void btnInt_Click(object sender, EventArgs e)
        {
            DeclareVar.iClick = true;
            DeclareVar.dClick = false;
            DeclareVar.fClick = false;

        }

        private void btnDouble_Click(object sender, EventArgs e)
        {
            DeclareVar.iClick = false;
            DeclareVar.dClick = true;
            DeclareVar.fClick = false;
        }

        private void btnFloat_Click(object sender, EventArgs e)
        {
            DeclareVar.iClick = false;
            DeclareVar.dClick = false;
            DeclareVar.fClick = true;
        }

        private void btnCompute_Click(object sender, EventArgs e)
        {
            if (DeclareVar.iClick == false && DeclareVar.dClick == false && DeclareVar.fClick == false)
            {
                MessageBox.Show("Please select if its Integer, double or float!","",MessageBoxButtons.OK,MessageBoxIcon.Warning);
            }
            if (DeclareVar.iClick == true)
            {
                DeclareVar.sum = Convert.ToInt32(txt1.Text) + Convert.ToInt32(txt2.Text);
                DeclareVar.iClick = false;
                MessageBox.Show("Sum is  " + DeclareVar.sum + "","Answer",MessageBoxButtons.OK,MessageBoxIcon.None);
                txt1.Clear();
                txt2.Clear();
            }
            if (DeclareVar.dClick == true)
            {
                DeclareVar.ans = Convert.ToDouble(txt1.Text) + Convert.ToDouble(txt2.Text);
                DeclareVar.dClick = false;
                MessageBox.Show("Sum is  " + DeclareVar.ans + "", "Answer", MessageBoxButtons.OK, MessageBoxIcon.None);

                txt1.Clear();
                txt2.Clear();
            }
            if (DeclareVar.fClick == true)
            {
                DeclareVar.sagot = Convert.ToSingle(txt1.Text) + Convert.ToSingle(txt2.Text);
                DeclareVar.fClick = false;
                MessageBox.Show("Sum is  " + DeclareVar.sagot + "", "Answer", MessageBoxButtons.OK, MessageBoxIcon.None);

                txt1.Clear();
                txt2.Clear();
            }
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            Form4 f = new Form4();
            this.Hide();
            f.ShowDialog();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            this.Hide();
            f1.ShowDialog();
        }
    }
}
