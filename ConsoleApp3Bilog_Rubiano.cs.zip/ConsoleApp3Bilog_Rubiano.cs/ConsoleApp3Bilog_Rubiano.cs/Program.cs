﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApp3.cs
{
    class Program
    {
        static void Main(string[] args)
        {
            DeclareVlaues D = new DeclareVlaues();
            D.declare();

            Average A = new Average();
            A.ave();


            Console.ReadKey();
        }
    }
}
