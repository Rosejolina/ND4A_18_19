﻿
namespace ConsoleApp3.cs
{
    class Average 
    {
        public double g1, g2, g3, g4, g5, sum, result;
        public void ave()
    {

        g1 = System.Convert.ToDouble(System.Console.ReadLine());
        g2 = System.Convert.ToDouble(System.Console.ReadLine());
        g3 = System.Convert.ToDouble(System.Console.ReadLine());
        g4 = System.Convert.ToDouble(System.Console.ReadLine());
        g5 = System.Convert.ToDouble(System.Console.ReadLine());

        sum = g1 + g2 + g3 + g4 + g5;
        result = sum / 5;
        System.Console.WriteLine("Average is {0:N3}", result);

        }
    }
}
