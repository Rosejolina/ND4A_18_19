﻿
namespace ConsoleApp3.cs
{
    class InputValues
    {
        public void val()
        {
            System.Console.Write("Enter 5 Grades: \n");
        }
    }
}
