﻿
namespace ConsoleApp3.cs
{
    class DeclareVlaues
    {
        public void declare()
        {
            InputValues I = new InputValues();
            I.val();


            
        }
    }
}
