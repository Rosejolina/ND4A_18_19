﻿
namespace ConsoleApp2
{
    class DeclareValues
    {
      
        public void ValuesDetails()
        {

            System.Console.Write("Enter 2 numbers: \n");

        }
    }
}