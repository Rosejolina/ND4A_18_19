﻿
namespace ConsoleApp2
{
    class Difference
    {
        public int a, b;
        public void minus()
        {
            DeclareValues d = new DeclareValues();
            d.ValuesDetails();

            a = System.Convert.ToInt32(System.Console.ReadLine());
            b = System.Convert.ToInt32(System.Console.ReadLine());


            System.Console.WriteLine("Difference = {0}", a - b);
            System.Console.ReadLine();
        }
    }
}
