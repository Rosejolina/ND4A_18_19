﻿
namespace ConsoleApp2
{
    class sum
    {
        public int a, b;
         public void add()
         {
             DeclareValues d = new DeclareValues();
             d.ValuesDetails();

             a=System.Convert.ToInt32(System.Console.ReadLine());
             b=System.Convert.ToInt32(System.Console.ReadLine());
             
          
             System.Console.WriteLine("Sum = {0}",  a + b);
             System.Console.ReadLine();
    }

    }
}
