﻿
namespace ConsoleApp2
{
    class Quotient
    {
        public int a, b;
        public void divide()
        {
            DeclareValues d = new DeclareValues();
            d.ValuesDetails();

            a = System.Convert.ToInt32(System.Console.ReadLine());
            b = System.Convert.ToInt32(System.Console.ReadLine());


            System.Console.WriteLine("Quotient = {0}", a / b);
            System.Console.ReadLine();
        }
    }
}
