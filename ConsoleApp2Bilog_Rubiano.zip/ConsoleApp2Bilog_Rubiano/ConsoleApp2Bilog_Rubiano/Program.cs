﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {
            sum s = new sum();
            s.add();

            Difference d = new Difference();
            d.minus();

            Product p = new Product();
            p.multiply();


            Quotient q = new Quotient();
            q.divide();


            Remainder r = new Remainder();
            r.rem();



            Console.ReadKey();
        }
    }
}
