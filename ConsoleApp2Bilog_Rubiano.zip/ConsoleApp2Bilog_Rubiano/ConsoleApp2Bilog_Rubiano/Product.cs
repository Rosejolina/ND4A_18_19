﻿
namespace ConsoleApp2
{
    class Product
    {
        public int a, b;
        public void multiply()
        {
            DeclareValues d = new DeclareValues();
            d.ValuesDetails();

            a = System.Convert.ToInt32(System.Console.ReadLine());
            b = System.Convert.ToInt32(System.Console.ReadLine());


            System.Console.WriteLine("Product = {0}", a * b);
            System.Console.ReadLine();
        }
    }
}